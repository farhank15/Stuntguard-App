import ChildDetail from "@/components/molecules/ChildDetail";
import React from "react";

const ChildDetailTemp = () => {
  return (
    <div className="pt-20 pb-20 font-poppins">
      <ChildDetail />
    </div>
  );
};

export default ChildDetailTemp;
