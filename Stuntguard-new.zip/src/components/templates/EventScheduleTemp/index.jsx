import EventSchedule from "@/components/molecules/EventSchedule";
import React from "react";

const EventTempTemp = () => {
  return (
    <div className="h-screen py-20 mx-auto font-poppins ">
      <EventSchedule />
    </div>
  );
};

export default EventTempTemp;
