import React from "react";
import EditChildForm from "../../molecules/EditChildForm";

const EditFormChildTemp = () => {
  return (
    <div>
      <EditChildForm />
    </div>
  );
};

export default EditFormChildTemp;
