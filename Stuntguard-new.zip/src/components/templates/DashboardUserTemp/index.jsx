import DashboardUser from "@/components/molecules/DashboardUser";
import React from "react";

const DashboardUserTemp = () => {
  return (
    <div className="h-screen pt-20 pb-20 font-poppins">
      <DashboardUser />
    </div>
  );
};

export default DashboardUserTemp;
