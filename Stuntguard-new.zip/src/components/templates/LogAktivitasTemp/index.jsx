import LogAktivitas from "@/components/molecules/LogAktivitas";
import React from "react";

const LogAktivitasTemp = () => {
  return (
    <div className="pt-20 pb-20 font-poppins">
      <LogAktivitas />
    </div>
  );
};

export default LogAktivitasTemp;
