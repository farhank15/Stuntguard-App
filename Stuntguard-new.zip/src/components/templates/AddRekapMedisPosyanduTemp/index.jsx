import AddRekapMedisPosyandu from "@/components/molecules/AddRekapMedisPosyandu";
import React from "react";

const AddRekapMedisPosyanduTemp = () => {
  return (
    <div className="pt-20 pb-20 font-poppins">
      <AddRekapMedisPosyandu />
    </div>
  );
};

export default AddRekapMedisPosyanduTemp;
