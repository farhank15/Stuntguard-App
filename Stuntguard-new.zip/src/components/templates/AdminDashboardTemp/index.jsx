import AdminDashboard from "@/components/molecules/AdminDashboard";
import React from "react";

const AdminDashboardTemp = () => {
  return (
    <div className="pt-20 pb-20 font-poppins">
      <AdminDashboard />
    </div>
  );
};

export default AdminDashboardTemp;
